<form class="w3-form" method="post" action="../scripts/register.php">
    <fieldset>
        Register for an Account
    </fieldset>
    <fieldset><br>
        Enter a Username: <br>
            <input class="w3-input" type="text" name="user"><br><br>
        Enter a Password: <br>
            <input class="w3-input" type="password" name="pword"><br><br>
        Confirm your Password: <br>
            <input class="w3-input" type="password" name="confirm"><br><br>
        <input class="w3-btn w3-grey" type="submit" value="Register">
    </fieldset>   
</form>
<p class="w3-container"><a href="login.php">Back to Login</a></p>