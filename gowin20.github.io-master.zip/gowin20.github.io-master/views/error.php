<h1>Sorry!</h1>
<p><?= htmlspecialchars($message) ?></p>
<a href="../index.php">Return</a>