<form class="w3-form" method="post" action="../scripts/login.php">
    <fieldset>
        Sign In
    </fieldset>
    <fieldset><br>
        Username: <br>
            <input class="w3-input" type="text" name="user"><br><br>
        Password: <br>
            <input class="w3-input" type="password" name="pword"><br><br>
        <input class="w3-btn w3-grey" type="submit" value="Submit">
    </fieldset>   
</form>
<p class="w3-container">
    Don't have an account? <a href="register.php">Register</a> for one now!
</p>