<?php

require("checker.php");
render("games.html", ["title" => "Sweet Games"]);

?>