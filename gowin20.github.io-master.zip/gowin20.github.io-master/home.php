<?php 
 require("scripts/checker.php");
 render("homepage.php", ["title" => "Home"]);
 ?>
