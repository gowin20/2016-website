<?php

require("scripts/checker.php");
render("games.html", ["title" => "Sweet Games"]);

?>